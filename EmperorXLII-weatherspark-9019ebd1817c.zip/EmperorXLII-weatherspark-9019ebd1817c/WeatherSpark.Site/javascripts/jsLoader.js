function require(jspath) {
    document.write('<script type="text/javascript" src="'+jspath+'"><\/script>');
}

require("https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js");
require("javascripts/plugins/easySlider1.7.min.js");
require("javascripts/plugins/jquery.tweet.min.js");